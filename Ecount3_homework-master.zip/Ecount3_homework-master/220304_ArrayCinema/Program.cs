﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _220304_ArrayCinema
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            Cinema cinema = new Cinema();
            cinema.mainmenu();
        }
    }
    
}
